package Tests;

import java.io.IOException;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Base.BaseTest;
import Pages.ApiGeneratorPage;

	public class GeneratorTest extends BaseTest {
	    private ApiGeneratorPage apiGeneratorPage;

	    @BeforeClass
	    public void initialize() {
	        setup();  
	        apiGeneratorPage = new ApiGeneratorPage(driver, wait);  
	    }

	    @Test(priority = 1)
	    public void testNavigateToApiGenerator() {
	        apiGeneratorPage.navigateToApiGenerator();
	        System.out.println("Test :1 Navigated to Url");
	    }

	    @Test(priority = 2, dependsOnMethods = "testNavigateToApiGenerator")
	    public void testFillAllColumns() throws InterruptedException {
	        apiGeneratorPage.fillAllColumns();
	        System.out.println("Test :2 Fill the Details of Inputs Fileds");
	    }

		@Test(priority = 3, dependsOnMethods = "testFillAllColumns")
		public void testGenrateAndVerifyAPI() throws InterruptedException
		{
			apiGeneratorPage.generateAndVerifyApi();
			System.out.println("Test :3 Genrated API details for 5 order");
		}
	     @Test(priority = 4,dependsOnMethods = "testGenrateAndVerifyAPI")
	     public void validateAPI() throws IOException
	     {
	    	 apiGeneratorPage.validateAPIResponse();
	    	 System.out.println("TesT :4 Validated the Respnse for API");
	     }
	    @AfterClass
	    public void cleanup() {
	        teardown();  
	    }
	}




