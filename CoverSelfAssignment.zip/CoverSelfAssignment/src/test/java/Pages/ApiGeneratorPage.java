package Pages;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.io.FileWriter;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

	public class ApiGeneratorPage {
	    private WebDriver driver;
	    private WebDriverWait wait;
	    private JavascriptExecutor jsExecutor;
	    public ApiGeneratorPage(WebDriver driver, WebDriverWait wait) {
	        this.driver = driver;
	        this.wait = wait;
	        this.jsExecutor = (JavascriptExecutor) driver;
	    }

	    public void navigateToApiGenerator() {
	       // driver.get("https://retool.com/api-generator/");
	        WebElement iframeSection = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='iframe-section']")));
	        jsExecutor.executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'start'});", iframeSection);
	        driver.switchTo().frame(driver.findElement(By.xpath("//*[@id='iframe-section']/iframe")));
	    }

	    public void fillAllColumns() throws InterruptedException {
	        clickAddColumn();
	        fillColumn(0, "Name", 1, "People", "Full Name", 1);
	        fillColumn(1, "OrderCount", 2, "Number", "Random", 1);
	        fillColumn(2, "Email", 3, "People", "Email Address", 2);
	        fillColumn(3, "ProductId", 4, "Number", "Product ID", 2);
	    }

	    public void generateAndVerifyApi() throws InterruptedException {
	        sendKeysWithClear("//*[@id=\"input_api_name--0\"]", "Order");
	        sendKeysWithClear("//*[@id=\"input_rows--0\"]", "5");

	        WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[text()='Generate API']")));
	        btn.click();

	        wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(
	            By.xpath("//div[@class=\"ReactVirtualized__Grid__innerScrollContainer\"]/div/div"), 4));

	        List<WebElement> childDivs = driver.findElements(By.xpath("//div[@class=\"ReactVirtualized__Grid__innerScrollContainer\"]/div/div"));
	        int size = childDivs.size();
	        System.out.println("Row Count: " + size);
	        assert size == 5 : "Table Rows are Incorrect!";
	    }

	    public void validateAPIResponse() throws IOException {
	        RequestSpecification request = RestAssured.given();
	        WebElement apiLink = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[contains(@href, 'retoolapi')]")));
	        jsExecutor.executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", apiLink);
	        wait.until(ExpectedConditions.visibilityOf(apiLink));
	        String endpointUrl = apiLink.getText();
	        System.out.println("Extracted Link: " + endpointUrl);

	        Response response = request.get(endpointUrl);
	        assert response.getStatusCode() == 200 : "API response status is not 200";

	        String responseBody = response.getBody().asPrettyString();
	        try (FileWriter file = new FileWriter("src/test/resources/orders.json")) {
	            file.write(responseBody);
	        }
	    }

	    private void fillColumn(int colIndex, String inputValue, int index, String firstDropdownValue, String secondDropdownValue, int lastIndex) throws InterruptedException {
	        sendKeysWithClear("//*[@id='input_name--" + colIndex + "']", inputValue);

	        WebElement dropDown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(
	            "(//span[contains(@class, 'ant-cascader-picker ant-cascader-picker-show-search')]//input)[" + index + "]")));
	        dropDown.click();
	        dropDown.sendKeys(firstDropdownValue);

	        WebElement dropdownOption = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(
	            "(//*[@id='skip-main']//ul/li[contains(@class, 'ant-cascader-menu-item') and contains(., '" + firstDropdownValue + "') and contains(., '" + secondDropdownValue + "')])[" + lastIndex + "]")));
	        jsExecutor.executeScript("arguments[0].click();", dropdownOption);
	    }

	    private void clickAddColumn() {
	        for (int i = 0; i < 3; i++) {
	            WebElement button = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[text()='Add Column']")));
	            button.click();
	        }
	    }

	    private void sendKeysWithClear(String xpath, String text) throws InterruptedException  {
	    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
			WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));
			element.click(); 
			Thread.sleep(3000); 
			element.sendKeys(Keys.CONTROL + "a", Keys.BACK_SPACE); 
			element.sendKeys(text); 
	    }
	}


